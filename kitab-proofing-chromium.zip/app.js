(async () => {
  // ---------- স্থায়ী সংরক্ষণ ----------
  // localStorage-এর পাশাপাশি, এক্সটেনশনে হলে chrome.storage.local-এও (Token, API Key, Prompt, Model, সেটিংস, খসড়া) অনুলিপি রাখা হয়।
  // শুরুতে সেখান থেকে ফিরিয়ে আনা হয়, তাই প্রতিবার নতুন করে দিতে হয় না। সাধারণ HTML-এ শুধু localStorage (+ স্থায়ী-স্টোরেজ অনুরোধ)।
  const KP_EXT = (typeof browser !== 'undefined' && browser.storage && browser.storage.local) ? browser
               : (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome : null;
  const KP_KEYS = ['kitab_proof_cfg_v1', 'kitab_proof_drafts_v1'];
  const kpPend = {}; let kpT = 0;
  function kpFlush() {
    clearTimeout(kpT);
    const o = {...kpPend}; Object.keys(kpPend).forEach(k => delete kpPend[k]);
    if (!KP_EXT || !Object.keys(o).length) return;
    try { const p = KP_EXT.storage.local.set(o); if (p && p.catch) p.catch(() => {}); } catch (e) {}
  }
  function kpMirror(k, v) { if (!KP_EXT) return; kpPend[k] = v; clearTimeout(kpT); kpT = setTimeout(kpFlush, 200); }
  addEventListener('pagehide', kpFlush);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') kpFlush(); });
  if (KP_EXT) {
    try {
      const got = await KP_EXT.storage.local.get(KP_KEYS);
      for (const k of KP_KEYS) {
        if (typeof got[k] === 'string' && got[k]) { try { localStorage.setItem(k, got[k]); } catch (e) {} }   // এক্সটেনশন স্টোরেজই মূল
        else { let v = null; try { v = localStorage.getItem(k); } catch (e) {} if (v) kpMirror(k, v); }         // আগের localStorage থেকে স্থানান্তর
      }
    } catch (e) {}
  }
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}   // ব্রাউজার যেন ডেটা নিজে থেকে মুছে না ফেলে

(() => {
  const $ = id => document.getElementById(id);
  const ic = n => '<svg class="i"><use href="#i-' + n + '"/></svg>';   // ছোট ভেক্টর আইকন
  const CK = 'kitab_proof_cfg_v1';      // সেটিংস + শেষ পেইজ + স্ক্রল/কার্সর অবস্থান
  const DK = 'kitab_proof_drafts_v1';   // অসংরক্ষিত খসড়া (পেইজ ধরে ধরে)
  const defaults = {
    repo:'SunniPedia/pdftojpg', branch:'', token:'',
    pagesDir:'pages', textsDir:'texts', proofFile:'proofed.json',
    fs:20, swap:false, zoom:100, last:'', view:null, autoHead:false,
    ttsRate:1, ttsEngine:'auto', tts:{bn:'', ar:'', en:''}
  };
  // ---------- API (Gemini) ডিফল্ট ----------
  const API_NAME = {1: 'এপি আই - ১', 2: 'এপি আই - ২'};
  const API_DEF = {
    1: {
      sub: 'ছবি থেকে টেক্সট (OCR)',
      prompt: [
        'এই ছবিটি একটি কিতাবের পেইজ। ছবির সব লেখা হুবহু টেক্সট আকারে তুলে দাও।',
        'নিয়ম:',
        '১) আরবি অংশ আরবি অক্ষরে, বাংলা অংশ বাংলা অক্ষরে লিখবে; এক শব্দে দুই লিপি মেশাবে না।',
        '২) আরবির হরকত/ইরাব ছবিতে থাকলে রাখবে।',
        '৩) পেইজ নম্বর, পাদটীকা ও মার্জিনের লেখাও যেমন আছে তেমন রাখবে।',
        '৪) নিজে থেকে কিছু যোগ, বাদ বা সংশোধন করবে না; পড়া না গেলে [অস্পষ্ট] লিখবে।',
        '৫) কোনো ভূমিকা, মন্তব্য বা markdown চিহ্ন (**, #, -) ব্যবহার করবে না; শুধু টেক্সট দেবে।'
      ].join('\n')
    },
    2: {
      sub: 'টেক্সট প্রুফিং',
      prompt: [
        'নিচে একটি কিতাবের পেইজের ছবি (থাকলে) এবং সেই ছবি থেকে OCR করা টেক্সট দেওয়া আছে। ছবির সাথে মিলিয়ে টেক্সটের ভুল সংশোধন করো: বানান, যুক্তাক্ষর, আরবি হরকত, বাদ পড়া বা বাড়তি শব্দ, ভুল লাইন ভাঙা।',
        'নিয়ম:',
        '১) অর্থ, ভাষা বা শব্দচয়ন বদলাবে না; নিজের থেকে কিছু যোগ করবে না।',
        '২) আরবি অংশ আরবিতে, বাংলা অংশ বাংলায় থাকবে; লিপি মেশাবে না।',
        '৩) অনুচ্ছেদ ও লাইনের কাঠামো যতটা সম্ভব আগের মতো রাখবে।',
        '৪) লাইনের শুরুতে হেডিং চিহ্ন হিসেবে 1 (স্পেস ছাড়া) থাকলে সেটা যেমন আছে তেমনই রাখবে।',
        '৫) markdown চিহ্ন ব্যবহার করবে না।',
        '৬) কোনো মন্তব্য বা ব্যাখ্যা ছাড়া শুধু সংশোধিত পূর্ণ টেক্সট দেবে।'
      ].join('\n')
    }
  };
  let cfg = {...defaults};
  try { cfg = {...defaults, ...JSON.parse(localStorage.getItem(CK) || '{}')}; } catch(e) {}
  if (!cfg.repo) cfg.repo = defaults.repo;
  if (!cfg.tts || typeof cfg.tts !== 'object') cfg.tts = {bn:'', ar:'', en:''};
  if (!['auto', 'device', 'google'].includes(cfg.ttsEngine)) cfg.ttsEngine = 'auto';
  // API ১ ও ২ এর সংরক্ষিত মান (পুরনো সংরক্ষণে এই ঘর না থাকলে ডিফল্ট বসবে)
  [1, 2].forEach(n => {
    const o = cfg['api' + n];
    cfg['api' + n] = {key: '', model: 'gemini-3.5-flash-lite', temp: 0, prompt: API_DEF[n].prompt, sendImg: true, auto: true,
                      ...(o && typeof o === 'object' ? o : {})};
  });
  // একবারের স্থানান্তর: আগের ডিফল্ট মডেল (gemini-3.5-flash) সংরক্ষিত থাকলে নতুন ডিফল্ট flash-lite হবে
  if (!cfg.apiMig1) {
    [1, 2].forEach(n => { if (cfg['api' + n].model === 'gemini-3.5-flash') cfg['api' + n].model = 'gemini-3.5-flash-lite'; });
    cfg.apiMig1 = 1;
  }
  const saveCfg = () => { let v; try { v = JSON.stringify(cfg); } catch(e) { return; } try { localStorage.setItem(CK, v); } catch(e) {} kpMirror(CK, v); };

  let drafts = {};
  try { drafts = JSON.parse(localStorage.getItem(DK) || '{}') || {}; } catch(e) { drafts = {}; }
  const dk = stem => cfg.repo + '/' + stem;
  let quotaWarned = false;
  function persistDrafts() {
    try { const v = JSON.stringify(drafts); kpMirror(DK, v); localStorage.setItem(DK, v); return true; }
    catch(e) {
      if (KP_EXT) return true;   // এক্সটেনশন স্টোরেজে খসড়া নিরাপদ আছে
      if (!quotaWarned) { quotaWarned = true; toast('লোকাল স্টোরেজে খসড়া রাখা যাচ্ছে না (জায়গা শেষ?) — দ্রুত সেভ করুন', true); }
      return false;
    }
  }

  // ---------- স্টেট ----------
  let images = [];            // [{name, stem}]
  let textSet = new Set();    // যেসব পেইজের txt আছে
  let proofed = new Set();    // প্রুফড পেইজের stem
  let proofSha = null;
  let cur = -1, sha = null, orig = '';
  let seq = 0, busy = false, loadErr = false;
  let initing = false, initFailed = false, forceInit = false;
  let restoreOnce = true, viewReady = false;
  const imgCache = new Map(); // name -> Promise<objectURL>
  let apiRun = null;          // চলমান API: {n, stem, ctrl, chars}
  let autoT = 0, autoPause = false;   // অটো OCR: ডিবাউন্স টাইমার; Key/কোটা ত্রুটিতে সাময়িক বিরতি
  const autoTried = new Set();        // এই সেশনে যেসব পেইজে API-১ একবার চলেছে (অটো বা হাতে)

  const ta = $('ta'), img = $('img'), sel = $('sel'), imgBox = $('imgBox');

  // ---------- হেল্পার ----------
  const te = new TextEncoder(), td = new TextDecoder();
  function toB64(str){
    const b = te.encode(str); let s = '';
    for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function fromB64(b64){
    const bin = atob(b64.replace(/\s/g, ''));
    return td.decode(Uint8Array.from(bin, c => c.charCodeAt(0)));
  }
  const epath = p => p.split('/').map(encodeURIComponent).join('/');
  const refQ = () => cfg.branch ? '?ref=' + encodeURIComponent(cfg.branch) : '';
  const natCmp = (a, b) => a.localeCompare(b, undefined, {numeric: true, sensitivity: 'base'});
  const numOf = stem => { const m = stem.match(/\d+/g); return m ? parseInt(m[m.length - 1], 10) : NaN; };
  const dirty = () => cur >= 0 && !ta.disabled && ta.value !== orig;

  let toastT;
  function toast(msg, err, ms) {
    const t = $('toast'); t.textContent = msg; t.className = 'show' + (err ? ' err' : '');
    clearTimeout(toastT); toastT = setTimeout(() => t.className = '', ms || (err ? 5000 : 1800));
  }

  // ---------- নিজস্ব ড্রপডাউন ----------
  // ব্রাউজারের নিজস্ব <select> পপআপ সিস্টেম ফন্টে দেখায়; তাই প্রতিটি <select> লুকিয়ে তার জায়গায়
  // বাটন + নিজস্ব পপআপ তালিকা বসানো হয় (একই Anek Bangla ফন্ট)। আসল <select> ভেতরে থাকে,
  // তাই .value / .options / onchange আগের মতোই কাজ করে।
  const selValue = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
  let ddOpen = null;
  function closeDD() {
    if (!ddOpen) return;
    ddOpen.pop.remove(); ddOpen.btn.setAttribute('aria-expanded', 'false'); ddOpen = null;
  }
  function openDD(el, btn) {
    const pop = document.createElement('div');
    pop.className = 'dd-pop'; pop.setAttribute('role', 'listbox');
    const curIdx = el.selectedIndex;
    Array.from(el.options).forEach((o, i) => {
      const it = document.createElement('div');
      it.className = 'dd-it' + (i === curIdx ? ' sel' : '');
      it.setAttribute('role', 'option');
      const t = document.createElement('span'); t.textContent = o.textContent; it.appendChild(t);
      if (i === curIdx) it.insertAdjacentHTML('beforeend', ic('check'));
      it.onclick = e => {
        e.stopPropagation();
        el.selectedIndex = i; el._sync();
        closeDD();
        el.dispatchEvent(new Event('change', {bubbles: true}));
      };
      pop.appendChild(it);
    });
    // মডাল ডায়ালগের ভেতরের ড্রপডাউন ডায়ালগের ভেতরেই বসাতে হয়, নইলে ডায়ালগের নিচে ঢাকা পড়ে
    (btn.closest('dialog') || document.body).appendChild(pop);
    const r = btn.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
    pop.style.minWidth = Math.min(Math.max(r.width, 150), vw - 16) + 'px';
    const below = vh - r.bottom - 8, above = r.top - 8;
    const down = below >= 260 || below >= above;
    const maxH = Math.max(120, Math.min(vh * 0.6, down ? below : above));
    pop.style.maxHeight = maxH + 'px';
    const h = Math.min(pop.scrollHeight, maxH);
    pop.style.top = (down ? r.bottom + 4 : Math.max(8, r.top - 4 - h)) + 'px';
    const w = pop.offsetWidth;
    let left = r.left; if (left + w > vw - 8) left = Math.max(8, vw - 8 - w);
    pop.style.left = left + 'px';
    const s = pop.querySelector('.sel');
    if (s) pop.scrollTop = s.offsetTop - pop.clientHeight / 2 + s.offsetHeight / 2;   // বর্তমানটি মাঝখানে
    btn.setAttribute('aria-expanded', 'true');
    ddOpen = {pop, btn};
  }
  function enhanceSelect(el) {
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'dd-btn'; btn.dataset.for = el.id;
    btn.setAttribute('aria-haspopup', 'listbox'); btn.setAttribute('aria-expanded', 'false');
    if (el.title) btn.title = el.title;
    if (el.getAttribute('aria-label')) btn.setAttribute('aria-label', el.getAttribute('aria-label'));
    el.style.display = 'none'; el.after(btn);
    const sync = () => {
      const o = el.options[el.selectedIndex];
      btn.innerHTML = '<span class="dd-t"></span><svg class="i dd-ch"><use href="#i-down"/></svg>';
      btn.firstChild.textContent = o ? o.textContent : '';
    };
    // কোড থেকে select.value বদলালেও বাটনের লেখা নিজে থেকে হালনাগাদ হবে
    Object.defineProperty(el, 'value', {configurable: true, get() { return selValue.get.call(el); }, set(v) { selValue.set.call(el, v); sync(); }});
    new MutationObserver(sync).observe(el, {childList: true, subtree: true, characterData: true});
    btn.onclick = e => {
      e.stopPropagation();
      if (ddOpen && ddOpen.btn === btn) { closeDD(); return; }
      closeDD(); openDD(el, btn);
    };
    el._sync = sync; sync();
  }
  document.addEventListener('click', e => { if (ddOpen && !ddOpen.pop.contains(e.target)) closeDD(); });
  window.addEventListener('resize', closeDD);
  window.addEventListener('scroll', e => { if (ddOpen && !ddOpen.pop.contains(e.target)) closeDD(); }, true);

  // হেডার/ফুটারে মাউসের চাকা ঘোরালে আড়াআড়ি স্ক্রল (ডেস্কটপের জন্য)
  [$('hdr'), $('ftr')].forEach(bar => bar.addEventListener('wheel', e => {
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX) && bar.scrollWidth > bar.clientWidth) { bar.scrollLeft += e.deltaY; e.preventDefault(); }
  }, {passive: false}));

  async function api(path, opts = {}) {
    const headers = {
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(cfg.token ? {'Authorization': 'Bearer ' + cfg.token} : {}),
      ...(opts.headers || {})
    };
    // no-store: সেভের পর পুরনো (ক্যাশ করা) টেক্সট/sha ফেরত আসা ঠেকায়
    return fetch('https://api.github.com/repos/' + cfg.repo + path, {cache: 'no-store', ...opts, headers});
  }
  async function errMsg(r) {
    let m = ''; try { m = (await r.json()).message || ''; } catch(e) {}
    let hint = '';
    if (r.status === 401) hint = ' (টোকেন ভুল বা মেয়াদ শেষ)';
    else if (r.status === 403) hint = ' (অনুমতি নেই বা রেট-লিমিট; টোকেন দিন)';
    else if (r.status === 404) hint = ' (রিপো/ফোল্ডার/ফাইল পাওয়া যায়নি — নাম বা টোকেনের অ্যাক্সেস দেখুন)';
    return r.status + ': ' + m + hint;
  }

  // ---------- খসড়া (লোকাল স্টোরেজে স্বয়ংক্রিয় সংরক্ষণ) ----------
  let draftT;
  function stashDraft() {
    clearTimeout(draftT);
    if (cur < 0 || ta.disabled) return;          // লোড চলাকালীন বা ব্যর্থ হলে খসড়া ছুঁবে না
    const k = dk(images[cur].stem);
    if (ta.value !== orig) drafts[k] = {t: ta.value, ts: Date.now()};
    else if (k in drafts) delete drafts[k];
    else return;
    persistDrafts();
    updateOption(cur);
  }

  // ---------- শেষ অবস্থান (স্ক্রল/কার্সর) সংরক্ষণ ----------
  let viewT;
  function saveView() {
    clearTimeout(viewT);
    if (cur < 0 || !viewReady) return;
    cfg.view = {
      stem: images[cur].stem,
      it: Math.round(imgBox.scrollTop), il: Math.round(imgBox.scrollLeft),
      tt: Math.round(ta.scrollTop), c: ta.selectionStart || 0
    };
    saveCfg();
  }
  const lazyView = () => { clearTimeout(viewT); viewT = setTimeout(saveView, 400); };
  const flush = () => { stashDraft(); saveView(); };

  // ---------- UI আপডেট ----------
  const label = im => im.stem
    + (proofed.has(im.stem) ? ' ✓' : '')
    + (drafts[dk(im.stem)] ? ' •' : '')
    + (textSet.has(im.stem) ? '' : ' (txt নেই)');
  function updateOption(i) { if (sel.options[i]) sel.options[i].textContent = label(images[i]); }

  function updateStatus() {
    const st = $('status');
    if (cur < 0) { st.textContent = ''; st.className = ''; }
    else {
      const stem = images[cur].stem;
      const d = dirty();
      let t = (cur + 1) + '/' + images.length;
      if (loadErr) t += ' • টেক্সট লোড ব্যর্থ (রিলোড চাপুন)';
      else if (ta.disabled) t += ' • লোড হচ্ছে…';
      else t += d ? ' • অসংরক্ষিত' : (sha ? ' • সেভড' : ' • টেক্সট নেই (পেস্ট করে সেভ করুন)');
      if (proofed.has(stem)) t += ' • প্রুফড';
      if (apiRun) t += ' • ' + API_NAME[apiRun.n] + ' চলছে' + (apiRun.stem !== stem ? ' (' + apiRun.stem + ')' : '') + (apiRun.chars ? ' ' + apiRun.chars + ' অক্ষর' : '') + '…';
      st.textContent = t;
      st.className = (d || loadErr) ? 'dirty' : '';
      const pf = proofed.has(stem), tb = $('btnToggleProof');
      tb.innerHTML = ic(pf ? 'checksq' : 'square') + '<span>প্রুফড</span>';
      tb.classList.toggle('on', pf);
      tb.title = pf ? 'প্রুফড চিহ্ন আছে — বাতিল করতে চাপুন' : 'প্রুফড হিসেবে চিহ্নিত করুন';
      const nd = Object.keys(drafts).filter(k => k.startsWith(cfg.repo + '/')).length;
      $('txtInfo').textContent = ta.value.length + ' অক্ষর' + (nd ? ' • খসড়া ' + nd : '');
    }
  }
  function renderSelect() {
    const keep = cur;
    sel.innerHTML = '';
    images.forEach((im, i) => {
      const o = document.createElement('option');
      o.value = i;
      o.textContent = label(im);
      sel.appendChild(o);
    });
    if (keep >= 0) sel.value = keep;
  }
  const applyZoom = () => { img.style.width = cfg.zoom + '%'; $('zVal').textContent = cfg.zoom + '%'; };
  const applyFont = () => document.documentElement.style.setProperty('--fs', cfg.fs + 'px');
  const applySwap = () => $('main').classList.toggle('swap', !!cfg.swap);

  // ---------- ছবি ----------
  function getImage(name) {
    if (imgCache.has(name)) return imgCache.get(name);
    const p = (async () => {
      const r = await api('/contents/' + epath(cfg.pagesDir + '/' + name) + refQ(),
                          {cache: 'default', headers: {'Accept': 'application/vnd.github.raw+json'}});
      if (!r.ok) throw new Error(await errMsg(r));
      return URL.createObjectURL(await r.blob());
    })();
    imgCache.set(name, p);
    p.catch(() => imgCache.delete(name));
    if (imgCache.size > 6) {
      const k = imgCache.keys().next().value;
      imgCache.get(k).then(u => URL.revokeObjectURL(u)).catch(() => {});
      imgCache.delete(k);
    }
    return p;
  }

  // ---------- মূল ছবি ডাউনলোড ----------
  async function downloadCurrent() {
    if (cur < 0) { toast('কোনো ছবি খোলা নেই', true); return; }
    const im = images[cur];
    const ext = (im.name.split('.').pop() || '').toLowerCase();
    const mime = {jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png', webp:'image/webp'}[ext] || 'application/octet-stream';
    try {
      toast('মূল ছবি আনা হচ্ছে…', false, 4000);
      // ক্যাশ নয়, রিপো থেকে সরাসরি মূল ফাইল (raw) আনা হচ্ছে
      const path = '/contents/' + epath(cfg.pagesDir + '/' + im.name) + refQ();
      let r = await api(path, {headers: {'Accept': 'application/vnd.github.raw+json'}});
      if (!r.ok) throw new Error(await errMsg(r));
      let buf = await r.arrayBuffer();

      // খুব ছোট হলে (ভুল/এরর রেসপন্স হতে পারে) download_url দিয়ে আবার চেষ্টা
      if (buf.byteLength < 2048) {
        const rj = await api(path);
        if (rj.ok) {
          const j = await rj.json();
          if (j.download_url) {
            const r2 = await fetch(j.download_url, {cache: 'no-store'});
            if (r2.ok) buf = await r2.arrayBuffer();
          }
        }
      }
      if (buf.byteLength < 2048) throw new Error('ফাইল ঠিকমতো আসেনি (' + buf.byteLength + ' বাইট)');

      const blob = new Blob([buf], {type: mime});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = im.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      toast('ডাউনলোড: ' + im.name + ' (' + (buf.byteLength / 1048576).toFixed(2) + ' MB)');
    } catch (e) { toast('ডাউনলোড ব্যর্থ: ' + e.message, true); }
  }

  // ---------- লাইটবক্স (পপআপ) ----------
  const lb = $('lb'), lbImg = $('lbImg');
  function openLightbox() {
    if (cur < 0 || !img.getAttribute('src')) return;
    lbImg.src = img.src;
    $('lbTitle').textContent = images[cur].name;
    lb.classList.add('open'); lb.setAttribute('aria-hidden', 'false');
  }
  function closeLightbox() {
    if (!lb.classList.contains('open')) return;
    lb.classList.remove('open'); lb.setAttribute('aria-hidden', 'true');
    lbImg.removeAttribute('src');
  }
  img.addEventListener('click', openLightbox);
  lb.addEventListener('click', closeLightbox);           // যেকোনো জায়গায় ক্লিক = বন্ধ
  $('lbDl').addEventListener('click', e => { e.stopPropagation(); downloadCurrent(); });
  $('btnDl').onclick = downloadCurrent;

  // ---------- পেইজ লোড ----------
  async function loadPage() {
    stopPlay();                         // পেইজ বদলালে শোনা বন্ধ
    const my = ++seq, im = images[cur];
    // শেষবার বন্ধ হওয়ার অবস্থান ফেরত আনা হবে শুধু প্রথম লোডে
    const pv = (restoreOnce && cfg.view && cfg.view.stem === im.stem) ? cfg.view : null;
    restoreOnce = false;
    viewReady = false; loadErr = false;
    closeLightbox();
    ta.value = ''; ta.disabled = true; ta.placeholder = ''; orig = ''; sha = null;
    img.removeAttribute('src');
    $('imgMsg').textContent = 'ছবি লোড হচ্ছে…';
    updateStatus();

    const imgP = getImage(im.name).then(url => new Promise(res => {
      if (my !== seq) return res();
      img.onload = () => {
        if (my === seq) { $('imgMsg').textContent = ''; if (pv) imgBox.scrollTo(pv.il || 0, pv.it || 0); }
        res();
      };
      img.onerror = () => { if (my === seq) $('imgMsg').textContent = 'ছবি দেখানো যায়নি'; res(); };
      img.src = url;
      imgBox.scrollTo(0, 0);
    })).catch(e => { if (my === seq) $('imgMsg').textContent = 'ছবি লোড ব্যর্থ: ' + e.message; });

    const txtP = (async () => {
      const r = await api('/contents/' + epath(cfg.textsDir + '/' + im.stem + '.txt') + refQ());
      if (my !== seq) return;
      let ok = true;
      if (r.status === 404) { sha = null; ta.value = ''; orig = ''; }   // ফাইল/ফোল্ডার নেই → ফাঁকা ঘর
      else if (r.ok) {
        const j = await r.json();
        if (my !== seq) return;
        sha = j.sha;
        ta.value = j.content ? fromB64(j.content) : '';
        orig = ta.value;   // textarea নিজে নতুন লাইন স্বাভাবিক করে, তাই তার মানই তুলনার ভিত্তি
      } else { ok = false; toast(await errMsg(r), true); }
      if (my !== seq) return;
      if (ok) {
        const k = dk(im.stem), d = drafts[k];
        if (d && d.t !== orig) { ta.value = d.t; toast('অসংরক্ষিত খসড়া ফিরিয়ে আনা হয়েছে — সেভ করলে পুশ হবে', false, 3500); }
        else if (d) { delete drafts[k]; persistDrafts(); }
        ta.disabled = false; ta.scrollTop = 0;
        ta.placeholder = 'এই পেইজের টেক্সট এখনো নেই — এখানে টেক্সট পেস্ট করে সেভ করুন';
        updateOption(cur);
      } else { loadErr = true; }
      updateStatus();
    })().catch(e => { if (my === seq) { loadErr = true; toast('টেক্সট লোড ব্যর্থ: ' + e.message, true); updateStatus(); } });

    await Promise.all([imgP, txtP]);
    if (my !== seq) return;
    if (pv && !ta.disabled) {
      const c = Math.min(pv.c || 0, ta.value.length);
      try { ta.setSelectionRange(c, c); } catch(e) {}
      ta.scrollTop = pv.tt || 0;
    }
    viewReady = true;
    maybeAutoOcr();                     // টেক্সট ফাঁকা হলে এপি আই - ১ নিজে থেকে চলবে
    if (cur + 1 < images.length) getImage(images[cur + 1].name).catch(() => {}); // পরের ছবি আগাম লোড
  }

  async function go(i) {
    if (i < 0 || i >= images.length || i === cur) { sel.value = cur; return; }
    if (busy) { toast('সেভ চলছে, একটু অপেক্ষা করুন'); sel.value = cur; return; }
    stopPlay();
    flush();  // বর্তমান পেইজের খসড়া লোকালে রেখে যাই (কোনো কিছু হারাবে না)
    cur = i; cfg.last = images[i].stem;
    if (!(restoreOnce && cfg.view && cfg.view.stem === cfg.last)) cfg.view = null;
    saveCfg();
    sel.value = i;
    await loadPage();
  }

  // ---------- সেভ ----------
  async function saveText() {
    if (cur < 0 || ta.disabled) return false;
    if (!dirty()) return true;
    if (busy) return false;
    stashDraft();                       // নেটওয়ার্ক ব্যর্থ হলেও লোকালে লেখা থেকে যাবে
    busy = true; $('status').textContent = 'সেভ হচ্ছে…';
    try {
      const im = images[cur], text = ta.value;
      const body = {message: 'Proofread ' + im.stem + '.txt', content: toB64(text)};
      if (sha) body.sha = sha;
      if (cfg.branch) body.branch = cfg.branch;
      // texts/ ফোল্ডার না থাকলে GitHub এই পাথে ফাইল তৈরির সময় ফোল্ডারও তৈরি করে দেয়
      const r = await api('/contents/' + epath(cfg.textsDir + '/' + im.stem + '.txt'),
                          {method: 'PUT', body: JSON.stringify(body), headers: {'Content-Type': 'application/json'}});
      if (!r.ok) {
        toast(await errMsg(r) + (r.status === 409 || r.status === 422 ? ' — রিলোড বাটন চেপে আবার চেষ্টা করুন (আপনার লেখা খসড়ায় নিরাপদ আছে)' : ''), true, 7000);
        return false;
      }
      const j = await r.json();
      sha = j.content.sha; orig = text; textSet.add(im.stem);
      stashDraft();                     // সেভের মধ্যে আবার কিছু লিখলে সেটা খসড়া থাকবে, নইলে খসড়া মুছে যাবে
      updateOption(cur); toast('সেভ হয়েছে (GitHub-এ পুশ)');
      return true;
    } catch (e) { toast('সেভ ব্যর্থ: ' + e.message + ' (লেখা খসড়ায় নিরাপদ আছে)', true); return false; }
    finally { busy = false; updateStatus(); }
  }

  async function setProofed(stem, val) {
    const had = proofed.has(stem);
    if (val) proofed.add(stem); else proofed.delete(stem);
    const data = JSON.stringify({proofed: [...proofed].sort(natCmp)}, null, 2) + '\n';
    const body = {message: 'Proofing status: ' + stem, content: toB64(data)};
    if (proofSha) body.sha = proofSha;
    if (cfg.branch) body.branch = cfg.branch;
    try {
      const r = await api('/contents/' + epath(cfg.proofFile),
                          {method: 'PUT', body: JSON.stringify(body), headers: {'Content-Type': 'application/json'}});
      if (!r.ok) throw new Error(await errMsg(r));
      proofSha = (await r.json()).content.sha;
      const i = images.findIndex(im => im.stem === stem); if (i >= 0) updateOption(i);
      updateStatus();
      return true;
    } catch (e) {
      if (had) proofed.add(stem); else proofed.delete(stem);   // ব্যর্থ হলে আগের অবস্থায় ফেরত
      toast('প্রুফড তালিকা সেভ ব্যর্থ: ' + e.message, true);
      const i = images.findIndex(im => im.stem === stem); if (i >= 0) updateOption(i);
      updateStatus();
      return false;
    }
  }

  // ---------- ইনিশিয়ালাইজ ----------
  async function init() {
    if (initing) return;
    initing = true; initFailed = false;
    autoTried.clear();
    flush();
    $('status').textContent = 'লোড হচ্ছে…';
    try {
      if (!cfg.token) toast('টোকেন নেই — শুধু দেখা যাবে, সেভ/পুশ হবে না (সেটিংস থেকে টোকেন দিন)', true, 4500);

      // ডিফল্ট ব্রাঞ্চ ও লেখার অনুমতি জানা
      const ri = await api('');
      if (!ri.ok) throw new Error(await errMsg(ri));
      const info = await ri.json();
      if (cfg.token && info.permissions && info.permissions.push === false)
        toast('এই টোকেনে রিপোতে লেখার অনুমতি নেই (Contents: Read and write দিন)', true, 6000);
      const br = cfg.branch || info.default_branch;

      // এক রিকোয়েস্টে পুরো ফাইল তালিকা (১০০০-এর বেশি পেইজেও কাজ করে)
      const rt = await api('/git/trees/' + encodeURIComponent(br) + '?recursive=1');
      if (!rt.ok) throw new Error(await errMsg(rt));
      const tj = await rt.json();
      if (tj.truncated) toast('সতর্কতা: রিপো খুব বড়, ফাইল তালিকা অসম্পূর্ণ হতে পারে', true);
      const blobs = (tj.tree || []).filter(e => e.type === 'blob');

      const pp = cfg.pagesDir + '/', tp = cfg.textsDir + '/';
      const direct = (e, pre) => e.path.startsWith(pre) && e.path.indexOf('/', pre.length) < 0;

      const imgs = blobs.filter(e => direct(e, pp) && /\.(jpe?g|png|webp)$/i.test(e.path))
                        .map(e => { const name = e.path.slice(pp.length); return {name, stem: name.replace(/\.[^.]+$/, '')}; })
                        .sort((a, b) => natCmp(a.name, b.name));
      if (!imgs.length) throw new Error(cfg.pagesDir + '/ ফোল্ডারে কোনো ছবি নেই');

      const ts = new Set();
      blobs.forEach(e => { if (direct(e, tp) && /\.txt$/i.test(e.path)) ts.add(e.path.slice(tp.length).replace(/\.txt$/i, '')); });
      if (!blobs.some(e => e.path.startsWith(tp)))
        toast(cfg.textsDir + '/ ফোল্ডার এখনো নেই — প্রথম সেভ করলেই নিজে থেকে তৈরি হবে', false, 4500);

      let ps = new Set(), psha = null;
      if (blobs.some(e => e.path === cfg.proofFile)) {
        const r3 = await api('/contents/' + epath(cfg.proofFile) + refQ());
        if (r3.ok) {
          const j = await r3.json(); psha = j.sha;
          try { (JSON.parse(fromB64(j.content)).proofed || []).forEach(s => ps.add(s)); } catch(e) {}
        }
      }

      images = imgs; textSet = ts; proofed = ps; proofSha = psha;
      cur = -1; renderSelect();
      let start = images.findIndex(im => im.stem === cfg.last);   // যেখানে ছিলেন সেখান থেকে শুরু
      if (start < 0) start = 0;
      restoreOnce = true;
      await go(start);
    } catch (e) {
      initFailed = true;
      $('status').textContent = '';
      toast('সংযোগ ব্যর্থ: ' + e.message, true);
      openSettings();
    } finally { initing = false; }
  }

  // ---------- সেটিংস ----------
  function fillVoiceSel(selId, l) {
    const s = $(selId), list = voicesFor(l), want = (cfg.tts || {})[l] || '';
    s.innerHTML = '';
    const o0 = document.createElement('option');
    o0.value = '';
    o0.textContent = list.length ? 'স্বয়ংক্রিয়' : 'এই ডিভাইসে ' + TTS_NAME[l] + ' ভয়েস দেখা যাচ্ছে না';
    s.appendChild(o0);
    list.forEach(v => {
      const o = document.createElement('option');
      o.value = v.voiceURI || v.name;
      o.textContent = v.name + ' (' + v.lang + ')';
      s.appendChild(o);
    });
    s.value = want;
    if (s.value !== want) s.value = '';
  }
  function openSettings() {
    $('cRepo').value = cfg.repo; $('cBranch').value = cfg.branch; $('cToken').value = cfg.token;
    $('cPages').value = cfg.pagesDir; $('cTexts').value = cfg.textsDir; $('cProof').value = cfg.proofFile;
    $('cEngine').value = cfg.ttsEngine;
    loadVoices();
    fillVoiceSel('cVoiceBn', 'bn'); fillVoiceSel('cVoiceAr', 'ar'); fillVoiceSel('cVoiceEn', 'en');
    const d = $('dlg'); if (!d.open) d.showModal();
  }
  $('btnSettings').onclick = openSettings;
  $('cCancel').onclick = () => $('dlg').close();
  $('cClearTok').onclick = () => { $('cToken').value = ''; cfg.token = ''; saveCfg(); toast('টোকেন মুছে ফেলা হয়েছে'); };
  $('cSave').onclick = () => {
    const oldRepo = connected.repo, oldBr = connected.branch;
    const repo = $('cRepo').value.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/^\/+|\/+$/g, '');
    if (!/^[^\/\s]+\/[^\/\s]+$/.test(repo)) { toast('রিপো owner/repo আকারে দিন', true); return; }
    cfg.repo = repo;
    cfg.branch = $('cBranch').value.trim();
    cfg.token = $('cToken').value.trim();
    cfg.pagesDir = $('cPages').value.trim().replace(/^\/+|\/+$/g, '') || 'pages';
    cfg.textsDir = $('cTexts').value.trim().replace(/^\/+|\/+$/g, '') || 'texts';
    cfg.proofFile = $('cProof').value.trim().replace(/^\/+/, '') || 'proofed.json';
    cfg.ttsEngine = $('cEngine').value;
    cfg.tts = {bn: $('cVoiceBn').value, ar: $('cVoiceAr').value, en: $('cVoiceEn').value};
    tts.forceG = false;                 // ইঞ্জিন/ভয়েস বদলালে স্বয়ংক্রিয় ফলব্যাক আবার প্রথম থেকে
    if (cfg.repo !== oldRepo || cfg.branch !== oldBr) { cfg.last = ''; cfg.view = null; }
    connected.repo = cfg.repo; connected.branch = cfg.branch;
    saveCfg();
    imgCache.clear();
    forceInit = true;
    $('dlg').close();
  };
  // ---------- স্বয়ংক্রিয় সংরক্ষণ (সেটিংস): ফর্মে যা বদলাবে সাথে সাথে সংরক্ষিত হবে ----------
  const connected = {repo: cfg.repo, branch: cfg.branch};   // সর্বশেষ যে রিপো/ব্রাঞ্চে সংযোগ হয়েছে
  const normRepo = v => v.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/^\/+|\/+$/g, '');
  const SETTINGS_FIELDS = {
    cRepo:    v => { const r = normRepo(v); if (/^[^\/\s]+\/[^\/\s]+$/.test(r)) cfg.repo = r; },
    cBranch:  v => { cfg.branch = v.trim(); },
    cToken:   v => { cfg.token = v.trim(); },
    cPages:   v => { cfg.pagesDir = v.trim().replace(/^\/+|\/+$/g, '') || 'pages'; },
    cTexts:   v => { cfg.textsDir = v.trim().replace(/^\/+|\/+$/g, '') || 'texts'; },
    cProof:   v => { cfg.proofFile = v.trim().replace(/^\/+/, '') || 'proofed.json'; },
    cEngine:  v => { cfg.ttsEngine = v; tts.forceG = false; },
    cVoiceBn: v => { cfg.tts = {...cfg.tts, bn: v}; },
    cVoiceAr: v => { cfg.tts = {...cfg.tts, ar: v}; },
    cVoiceEn: v => { cfg.tts = {...cfg.tts, en: v}; }
  };
  Object.keys(SETTINGS_FIELDS).forEach(id => {
    const el = $(id), h = () => { SETTINGS_FIELDS[id](el.value); saveCfg(); };
    el.addEventListener('input', h); el.addEventListener('change', h);
  });

  // ডায়ালগ বন্ধ হলে: সেভ করলে বা প্রথমবার (তালিকা নেই) হলে সংযোগ শুরু
  $('dlg').addEventListener('close', () => {
    closeDD();
    if (forceInit || (!images.length && !initFailed && !initing)) { forceInit = false; init(); }
  });
  // খোলা ড্রপডাউনে Esc চাপলে শুধু ড্রপডাউন বন্ধ হবে, পুরো ডায়ালগ নয়
  $('dlg').addEventListener('cancel', e => { if (ddOpen) { e.preventDefault(); closeDD(); } });

  // ---------- ইভেন্ট ----------
  $('btnReload').onclick = () => { imgCache.clear(); init(); };
  $('btnPrev').onclick = () => go(cur - 1);
  $('btnNext').onclick = () => go(cur + 1);
  sel.onchange = () => go(parseInt(sel.value, 10));
  function jumpTo() {
    const n = parseInt($('jump').value, 10);
    if (!n) return;
    let i = images.findIndex(im => numOf(im.stem) === n);
    if (i < 0 && n >= 1 && n <= images.length) i = n - 1;
    if (i < 0) { toast('এই নম্বরের পেইজ নেই', true); return; }
    go(i);
  }
  $('btnGo').onclick = jumpTo;
  $('jump').addEventListener('keydown', e => { if (e.key === 'Enter') jumpTo(); });
  $('btnNextUn').onclick = () => {
    for (let k = 1; k <= images.length; k++) {
      const i = (cur + k) % images.length;
      if (!proofed.has(images[i].stem)) { go(i); return; }
    }
    toast('সব পেইজ প্রুফড!');
  };
  $('btnSwap').onclick = () => { cfg.swap = !cfg.swap; saveCfg(); applySwap(); };
  $('zIn').onclick  = () => { cfg.zoom = Math.min(400, cfg.zoom + 25); saveCfg(); applyZoom(); };
  $('zOut').onclick = () => { cfg.zoom = Math.max(50, cfg.zoom - 25); saveCfg(); applyZoom(); };
  $('zFit').onclick = () => { cfg.zoom = 100; saveCfg(); applyZoom(); };
  $('fIn').onclick  = () => { cfg.fs = Math.min(40, cfg.fs + 2); saveCfg(); applyFont(); };
  $('fOut').onclick = () => { cfg.fs = Math.max(12, cfg.fs - 2); saveCfg(); applyFont(); };

  // টাইপ করলেই (০.৩ সেকেন্ড থেমে) লোকাল স্টোরেজে খসড়া সংরক্ষণ
  ta.addEventListener('input', () => {
    updateStatus();
    clearTimeout(draftT); draftT = setTimeout(stashDraft, 300);
    lazyView();
  });
  ta.addEventListener('scroll', lazyView, {passive: true});
  ta.addEventListener('keyup', lazyView);
  ta.addEventListener('click', lazyView);
  imgBox.addEventListener('scroll', lazyView, {passive: true});

  // ---------- কপি / পেস্ট (পেস্টের পর কার্সর শুরুতে) ----------
  // ---------- অটো হেডিং: পেস্ট করা টেক্সটে হেডিং শনাক্ত করে আগে (স্পেস ছাড়া) 1 বসানো ----------
  const AR_RE   = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;           // আরবি/ফার্সি লাইন বাদ
  const BN_LET  = /[\u0985-\u09B9\u09CE\u09DC-\u09DF A-Za-z]/;                         // অন্তত একটি অক্ষর (শুধু সংখ্যা/চিহ্ন নয়)
  const END_RE  = /[।.?!,;:]["”’'\)\]]*$/;                                            // বাক্যের শেষ চিহ্ন
  const SENT_RE = /[।.?!]["”’'\)\]]*$/;                                               // আগের বাক্য শেষ হয়েছে কি না
  const KEY_RE  = /^(দলিল|অধ্যায়|পরিচ্ছেদ|অনুচ্ছেদ|ভূমিকা|মুখবন্ধ|সূচিপত্র|উপসংহার|পর্ব|প্রশ্ন|উত্তর|প্রসঙ্গ|বিষয়)(?![\u0980-\u09FF])/;
  function isHeading(line, prev, first) {
    const t = line.trim();
    if (!t || t.length > 80) return false;
    if (AR_RE.test(t) || !BN_LET.test(t)) return false;      // আরবি লাইন, পেইজ নম্বর ইত্যাদি নয়
    if (/^1[\u0980-\u09FF]/.test(t)) return false;           // আগেই চিহ্নিত
    if (/[।.?!,;]["”’'\)\]]*$/.test(t)) return false;        // বাক্য শেষ হলে হেডিং নয়
    if (KEY_RE.test(t)) return true;                         // দলিল/অধ্যায়… দিয়ে শুরু
    if (t.length > 50 || t.split(/\s+/).length > 8) return false;   // হেডিং ছোট হয়
    if (/[–—\-]$/.test(t) && !/[\d০-৯]/.test(t)) return false;      // "…আছে–" ধরনের পরিচায়ক লাইন নয়
    if (/:$/.test(t) && t.split(/\s+/).length > 4) return false;
    const p = (prev || '').trim();
    return first || p === '' || SENT_RE.test(p);              // আগের প্যারাগ্রাফ শেষ হয়ে নতুন লাইনে এসেছে
  }
  function markHeadings(text) {
    const lines = text.split(/\r?\n/);
    let n = 0;
    const out = lines.map((ln, i) => {
      if (isHeading(ln, i ? lines[i - 1] : '', i === 0)) { n++; return '1' + ln.trim(); }
      return ln;
    });
    return {text: out.join('\n'), n};
  }
  function applyAuto() {
    const b = $('btnAuto');
    b.classList.toggle('on', !!cfg.autoHead);
    b.setAttribute('aria-pressed', cfg.autoHead ? 'true' : 'false');
    b.innerHTML = ic('tag') + '<span>হেডিং: ' + (cfg.autoHead ? 'চালু' : 'বন্ধ') + '</span>';
  }
  $('btnAuto').onclick = () => {
    cfg.autoHead = !cfg.autoHead; saveCfg(); applyAuto();
    toast(cfg.autoHead ? 'অটো হেডিং চালু — পেস্টে হেডিংয়ের আগে 1 বসবে' : 'অটো হেডিং বন্ধ');
  };

  // replaceAll = true হলে আগের সব টেক্সট মুছে নতুন টেক্সট বসবে (আনডু (Ctrl+Z) কাজ করবে)
  // নইলে বর্তমান নির্বাচন/কার্সরের জায়গায় বসবে। উভয় ক্ষেত্রে বসানোর পর কার্সর বসানো টেক্সটের শুরুতে থাকে।
  function insertAtStart(text, replaceAll, quiet) {
    if (!text) return -1;
    let hn = -1;
    if (cfg.autoHead) { const r = markHeadings(text); text = r.text; hn = r.n; }
    ta.focus({preventScroll: true});
    if (replaceAll) ta.setSelectionRange(0, ta.value.length);   // পুরো টেক্সট নির্বাচন → নতুন টেক্সট তার জায়গা নেবে
    const s = ta.selectionStart, e = ta.selectionEnd;
    let done = false;
    try { done = document.execCommand('insertText', false, text); } catch(_) {}   // আনডু ঠিক রাখে
    if (!done) {
      ta.setRangeText(text, s, e, 'end');
      ta.dispatchEvent(new Event('input', {bubbles: true}));
    }
    ta.setSelectionRange(s, s);               // কার্সর বসানো টেক্সটের শুরুতে
    if (s === 0) ta.scrollTop = 0;            // শুরু থেকে দেখাবে
    if (!quiet) {
      if (replaceAll) toast('আগের টেক্সট মুছে নতুন টেক্সট বসানো হয়েছে' + (hn >= 0 ? ' • ' + hn + 'টি হেডিং চিহ্নিত (1 বসানো)' : ''));
      else if (hn >= 0) toast(hn + 'টি হেডিং চিহ্নিত হয়েছে (1 বসানো)');
    }
    lazyView();
    return hn;
  }
  $('btnPaste').onclick = async () => {
    if (cur < 0 || ta.disabled) return;
    try {
      const t = await navigator.clipboard.readText();
      if (!t) { toast('ক্লিপবোর্ড খালি', true); return; }
      insertAtStart(t, true);                 // পেস্ট বাটন: আগের সব টেক্সট মুছে নতুন টেক্সট
    } catch (e) {
      ta.focus();
      ta.select();                            // সব নির্বাচিত থাকবে, তাই হাতে পেস্ট করলেও আগের টেক্সট মুছে যাবে
      toast('ব্রাউজার ক্লিপবোর্ড পড়তে দিচ্ছে না — পুরো টেক্সট নির্বাচিত আছে, টেক্সট বক্সে চেপে ধরে/Ctrl+V দিয়ে পেস্ট করুন (আগের টেক্সট মুছে নতুনটি বসবে)', true, 6500);
    }
  };
  // সাধারণ পেস্ট (Ctrl+V / লং-প্রেস): নির্বাচন/কার্সরের জায়গায় বসে, তারপর কার্সর শুরুতে থাকে
  ta.addEventListener('paste', e => {
    const t = e.clipboardData && e.clipboardData.getData('text');
    if (!t) return;
    e.preventDefault();
    insertAtStart(t, false);
  });
  $('btnCopy').onclick = async () => {
    if (cur < 0) return;
    const a = ta.selectionStart, b = ta.selectionEnd;
    const part = a !== b;
    const text = part ? ta.value.slice(a, b) : ta.value;
    if (!text) { toast('কপি করার মতো টেক্সট নেই', true); return; }
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; }
    catch (e) {
      try { ta.focus(); if (!part) ta.select(); ok = document.execCommand('copy'); if (!part) ta.setSelectionRange(a, b); } catch (_) {}
    }
    toast(ok ? (part ? 'নির্বাচিত অংশ কপি হয়েছে' : 'পুরো টেক্সট কপি হয়েছে') : 'কপি ব্যর্থ', !ok);
  };

  // ---------- শোনা (TTS) ----------
  // দুই ইঞ্জিন: (১) ফোনের নিজস্ব TTS (speechSynthesis), (২) Google Translate-এর অনলাইন অডিও (অনানুষ্ঠানিক, কী লাগে না)।
  // "স্বয়ংক্রিয়" মোডে ফোনের TTS (ও সেই ভাষার ভয়েস) থাকলে সেটা, না থাকলে বা সাড়া না দিলে Google অনলাইন।
  // নির্বাচিত অংশ থাকলে সেটুকু, নইলে কার্সর থেকে শেষ পর্যন্ত পড়ে। বাংলা/আরবি/ইংরেজি আলাদা করে চিনে।
  const hasTTS = 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
  const TTS_LANG = {bn:'bn-BD', ar:'ar-SA', en:'en-US'};     // ফোনের TTS-এর ভাষা কোড
  const G_LANG   = {bn:'bn', ar:'ar', en:'en'};              // Google-এর ভাষা কোড
  const TTS_NAME = {bn:'বাংলা', ar:'আরবি', en:'ইংরেজি'};
  const TTS_MAX  = 180;                                      // এক খণ্ডে সর্বোচ্চ অক্ষর (Google সীমা ~200)
  const TTS_SENT = /[।.?!۔؟]["”’'\)\]]*$/;                    // বাক্য শেষ
  let voices = [], ttsWarned = {};
  const tts = {id:0, chunks:[], i:0, state:'idle', start:0, u:null, ga:null, cache:{}, forceG:false, wd:0, stale:false};   // state: idle | playing | paused

  function loadVoices() { try { voices = hasTTS ? (speechSynthesis.getVoices() || []) : []; } catch(e) { voices = []; } }
  if (hasTTS) { loadVoices(); try { speechSynthesis.addEventListener('voiceschanged', loadVoices); } catch(e) {} }
  const cancelDev = () => { if (hasTTS) { try { speechSynthesis.cancel(); } catch(e) {} } };
  const vLang = v => (v.lang || '').replace('_', '-').toLowerCase();
  const voicesFor = l => voices.filter(v => vLang(v).startsWith(l));
  function pickVoice(l) {
    const want = (cfg.tts || {})[l];
    if (want) { const v = voices.find(v => v.voiceURI === want || v.name === want); if (v) return v; }
    const list = voicesFor(l);
    return list.find(v => vLang(v) === TTS_LANG[l].toLowerCase()) || list[0] || null;
  }
  function wordLang(w) {
    if (AR_RE.test(w)) return 'ar';
    if (/[\u0980-\u09FF]/.test(w)) return 'bn';
    if (/[A-Za-z]/.test(w)) return 'en';
    return null;                              // সংখ্যা/চিহ্ন: আগের ভাষাতেই থাকবে
  }
  // টেক্সটকে ভাষা অনুযায়ী খণ্ডে ভাগ; প্রতিটি খণ্ডের off = ta.value-তে শুরুর অবস্থান
  function buildChunks(text, from, to) {
    const seg = text.slice(from, to), out = [];
    let c = null, last = 'bn', lastEnd = 0, inHead = false, first = true;
    const fl = () => { if (c && c.t.trim()) out.push(c); c = null; };
    const re = /\S+/g; let m;
    while ((m = re.exec(seg))) {
      const gap = seg.slice(lastEnd, m.index); lastEnd = m.index + m[0].length;
      const nl = first || /\n/.test(gap); first = false;
      let w = m[0], head = false, skip = 0;
      if (nl && /^1(?=[\u0980-\u09FF])/.test(w)) { w = w.slice(1); head = true; skip = 1; }   // হেডিং চিহ্ন 1 পড়া হবে না
      if (nl && inHead) { fl(); inHead = false; }                // হেডিং লাইন শেষ
      if (/\n\s*\n/.test(gap)) fl();                             // ফাঁকা লাইন = অনুচ্ছেদ শেষ
      if (head) { fl(); inHead = true; }
      if (!w) continue;
      const L = wordLang(w) || (c ? c.lang : last);
      if (c && (c.lang !== L || c.t.length + w.length + 1 > TTS_MAX)) fl();
      if (!c) c = {t: '', lang: L, off: from + m.index, end: 0, w: []};
      c.t += (c.t ? ' ' : '') + w;
      c.w.push({p: c.t.length - w.length, o: from + m.index + skip, l: w.length});   // শব্দের অবস্থান: c.t-তে (p) ও মূল টেক্সটে (o)
      c.end = from + m.index + m[0].length;
      last = L;
      if (TTS_SENT.test(w)) fl();
    }
    fl();
    return out;
  }
  function ttsUI() {
    const b = $('btnPlay'); if (!b) return;
    const pl = tts.state === 'playing';
    b.innerHTML = ic(pl ? 'pause' : 'play') + '<span>' + (pl ? 'বিরতি' : (tts.state === 'paused' ? 'চালান' : 'শুনুন')) + '</span>';
    b.classList.toggle('on', pl);
    $('btnStop').disabled = tts.state === 'idle';
  }
  // ---------- পড়ার সময় টেক্সট হাইলাইট ----------
  // বর্তমান খণ্ড (বাক্য) হালকা হলুদে; ফোনের TTS শব্দ-সীমা (boundary) জানালে বর্তমান শব্দ গাঢ় কমলায়।
  // textarea-র পেছনে একই ফন্ট/মাপের আয়না-স্তর (#hl) থেকে রং আসে, তাই ফোকাস/কিবোর্ড লাগে না।
  const hlEl = $('hl');
  const hlEsc = t => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  function hlClear() { hlEl.style.display = 'none'; hlEl.textContent = ''; }
  function hlShow(a, b, wa, wb) {
    const t = ta.value;
    if (tts.stale || b <= a || b > t.length) return false;       // টেক্সট বদলে গেছে → আর হাইলাইট নয়
    let h;
    if (wa >= a && wb > wa && wb <= b)
      h = hlEsc(t.slice(0, a)) + '<mark class="c">' + hlEsc(t.slice(a, wa)) + '<mark class="w">' + hlEsc(t.slice(wa, wb)) + '</mark>'
        + hlEsc(t.slice(wb, b)) + '</mark>' + hlEsc(t.slice(b));
    else h = hlEsc(t.slice(0, a)) + '<mark class="c">' + hlEsc(t.slice(a, b)) + '</mark>' + hlEsc(t.slice(b));
    hlEl.innerHTML = h + '\u200b';
    hlEl.style.display = 'block';
    const m = hlEl.querySelector('mark.w') || hlEl.querySelector('mark.c');
    if (m) {                                                      // হাইলাইট দেখার জায়গার বাইরে গেলে স্ক্রল করে ওপরের দিকে আনা
      const top = m.offsetTop, bot = top + m.offsetHeight, vh = ta.clientHeight;
      if (top < ta.scrollTop + vh * 0.08 || bot > ta.scrollTop + vh * 0.8) ta.scrollTop = Math.max(0, top - vh * 0.25);
    }
    hlEl.scrollTop = ta.scrollTop;
    return true;
  }
  ta.addEventListener('scroll', () => { if (hlEl.style.display !== 'none') hlEl.scrollTop = ta.scrollTop; }, {passive: true});
  // শোনার মধ্যে টেক্সট বদলালে অবস্থান-হিসাব মেলে না: হাইলাইট মুছে দেওয়া হয় (পরের বার "শুনুন" চাপলে আবার চলবে)
  ta.addEventListener('input', () => { if (tts.state !== 'idle' && !tts.stale) { tts.stale = true; hlClear(); } });

  // পড়ার সাথে সাথে কার্সর/স্ক্রল অনুসরণ + হাইলাইট (ফোকাস না নিয়ে, তাই কিবোর্ড খুলবে না)
  function follow(c) {
    try { ta.setSelectionRange(c.off, c.off); } catch(e) {}
    if (hlShow(c.off, c.end, -1, -1)) return;
    const ratio = c.off / Math.max(1, ta.value.length);
    ta.scrollTop = Math.max(0, ta.scrollHeight * ratio - ta.clientHeight * 0.3);
  }
  function killAudio(a) {
    if (!a) return;
    try { a.onplay = a.onended = a.onerror = null; a.pause(); a.removeAttribute('src'); a.load(); } catch(e) {}
  }
  function clearG() {
    killAudio(tts.ga); tts.ga = null;
    Object.keys(tts.cache).forEach(k => killAudio(tts.cache[k]));
    tts.cache = {};
  }
  function stopPlay() {
    tts.id++;
    clearTimeout(tts.wd);
    cancelDev();
    clearG();
    tts.state = 'idle'; tts.u = null;
    hlClear();
    ttsUI();
  }
  function finishPlay() {
    tts.state = 'idle'; tts.i = 0; tts.u = null; clearG(); hlClear(); ttsUI();
    try { ta.setSelectionRange(tts.start, tts.start); } catch(e) {}
    toast('পড়া শেষ');
  }

  // --- Google অনলাইন অডিও ---
  function gAudio(i) {
    if (tts.cache[i]) return tts.cache[i];
    const c = tts.chunks[i]; if (!c) return null;
    const a = new Audio();
    a.preload = 'auto';
    try { a.referrerPolicy = 'no-referrer'; } catch(e) {}
    a.src = 'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + G_LANG[c.lang] + '&q=' + encodeURIComponent(c.t);
    tts.cache[i] = a;
    return a;
  }
  function playG(i, id) {
    if (id !== tts.id) return;
    const c = tts.chunks[i], a = gAudio(i);
    if (!a) { stopPlay(); return; }
    tts.ga = a;
    try { a.playbackRate = Math.min(2, Math.max(0.5, parseFloat(cfg.ttsRate) || 1)); a.preservesPitch = true; } catch(e) {}
    a.onplay  = () => { if (id === tts.id) follow(c); };
    a.onended = () => { if (id === tts.id) { delete tts.cache[i]; speakChunk(i + 1, id); } };
    a.onerror = () => {
      if (id !== tts.id) return;
      stopPlay();
      toast('Google অডিও পাওয়া যায়নি — ইন্টারনেট দেখুন (সার্ভিসটি ব্লক বা সীমিত হয়ে থাকতে পারে)', true, 6500);
    };
    const p = a.play();
    if (p && p.catch) p.catch(err => {
      if (id !== tts.id) return;
      if (err && err.name === 'AbortError') return;
      stopPlay();
      toast('অডিও চালানো যায়নি' + (err && err.name === 'NotAllowedError' ? ' — ব্রাউজার অনুমতি দেয়নি, আবার "শুনুন" চাপুন' : ' — ইন্টারনেট/সার্ভিস দেখুন'), true, 6500);
    });
    if (i + 1 < tts.chunks.length) gAudio(i + 1);     // পরের খণ্ড আগাম লোড
  }

  // --- ফোনের TTS ---
  function speakChunk(i, id) {
    if (id !== tts.id) return;
    if (i >= tts.chunks.length) { finishPlay(); return; }
    tts.i = i;
    const c = tts.chunks[i], eng = cfg.ttsEngine || 'auto';
    const v = hasTTS ? pickVoice(c.lang) : null;
    const useG = eng === 'google' || (eng === 'auto' && (tts.forceG || !hasTTS || !v));
    if (useG) { playG(i, id); return; }
    if (!hasTTS) { stopPlay(); toast('এই ব্রাউজারে ফোনের টেক্সট-টু-স্পিচ নেই — সেটিংসে ইঞ্জিন "স্বয়ংক্রিয়" বা "Google অনলাইন" করুন', true, 6000); return; }

    const fallbackToG = why => {
      if (id !== tts.id || eng !== 'auto') return false;
      tts.forceG = true; clearTimeout(tts.wd); cancelDev();
      toast('ফোনের TTS ' + why + ' — Google অনলাইন ভয়েস ব্যবহার হচ্ছে', false, 3500);
      playG(i, id);
      return true;
    };
    const u = new SpeechSynthesisUtterance(c.t);
    u.lang = TTS_LANG[c.lang];
    if (v) { u.voice = v; u.lang = v.lang; }
    else if (voices.length && !ttsWarned[c.lang]) {
      ttsWarned[c.lang] = 1;
      toast(TTS_NAME[c.lang] + ' ভয়েস পাওয়া যায়নি — ফোনের টেক্সট-টু-স্পিচ সেটিংসে ভয়েস ডেটা ডাউনলোড করুন', true, 6000);
    }
    u.rate = parseFloat(cfg.ttsRate) || 1;
    let started = false;
    u.onstart = () => { started = true; clearTimeout(tts.wd); if (id === tts.id) follow(c); };
    u.onboundary = ev => {                    // শব্দ-সীমা: সব ইঞ্জিন পাঠায় না; পেলে বর্তমান শব্দ গাঢ় হাইলাইট
      if (id !== tts.id || tts.stale || (ev.name && ev.name !== 'word') || !c.w) return;
      let wd = null;
      for (let k = 0; k < c.w.length; k++) { if (c.w[k].p <= ev.charIndex) wd = c.w[k]; else break; }
      if (wd) hlShow(c.off, c.end, wd.o, wd.o + wd.l);
    };
    u.onend   = () => { clearTimeout(tts.wd); if (id === tts.id) speakChunk(i + 1, id); };
    u.onerror = e => {
      if (id !== tts.id) return;
      if (e.error === 'canceled' || e.error === 'interrupted') return;
      if (fallbackToG('সাড়া দেয়নি (' + (e.error || 'ত্রুটি') + ')')) return;
      stopPlay();
      toast('পড়তে সমস্যা: ' + (e.error || 'অজানা') + (e.error === 'language-unavailable' ? ' (এই ভাষার ভয়েস নেই)' : ''), true);
    };
    tts.u = u;                                // ব্রাউজার যেন অবজেক্ট মুছে না ফেলে
    try { speechSynthesis.speak(u); } catch(err) { if (!fallbackToG('চালু করা যায়নি')) { stopPlay(); toast('TTS চালু করা যায়নি', true); } return; }
    if (eng === 'auto') {                     // কিছু ফোনে TTS কোনো ত্রুটি ছাড়াই নীরব থাকে → ৪ সেকেন্ডে সাড়া না এলে Google
      clearTimeout(tts.wd);
      tts.wd = setTimeout(() => { if (id === tts.id && !started) fallbackToG('সাড়া দিচ্ছে না'); }, 4000);
    }
  }
  function startFrom(i) {
    tts.id++;
    const id = tts.id;
    clearTimeout(tts.wd);
    cancelDev();
    tts.state = 'playing'; ttsUI();
    setTimeout(() => speakChunk(i, id), 80);  // cancel-এর পরপরই speak করলে কিছু ব্রাউজার গিলে ফেলে
  }
  function playClick() {
    if (cur < 0 || ta.disabled) return;
    if (tts.state === 'playing') {            // বিরতি: থামিয়ে এই খণ্ডটির শুরু থেকে আবার চালানো হয় (Android-এ pause অনির্ভরযোগ্য)
      tts.id++;
      clearTimeout(tts.wd);
      cancelDev();
      killAudio(tts.ga); tts.ga = null; delete tts.cache[tts.i];
      tts.state = 'paused'; ttsUI();
      return;
    }
    if (tts.state === 'paused') { startFrom(tts.i); return; }
    const text = ta.value;
    if (!text.trim()) { toast('পড়ার মতো টেক্সট নেই', true); return; }
    let a = ta.selectionStart, b = ta.selectionEnd;
    if (a === b) { b = text.length; if (a >= b - 1) a = 0; }   // নির্বাচন নেই → কার্সর থেকে শেষ (শেষে থাকলে শুরু থেকে)
    loadVoices(); ttsWarned = {};
    tts.chunks = buildChunks(text, a, b);
    tts.stale = false;
    if (!tts.chunks.length) { toast('পড়ার মতো টেক্সট নেই', true); return; }
    tts.start = a;
    const langs = [...new Set(tts.chunks.map(c => TTS_NAME[c.lang]))].join(' + ');
    toast('শোনা শুরু • ভাষা: ' + langs);
    startFrom(0);
  }
  $('btnPlay').onclick = playClick;
  $('btnStop').onclick = () => { stopPlay(); toast('শোনা বন্ধ'); };
  $('ttsRate').value = String(cfg.ttsRate || 1);
  if ($('ttsRate').value !== String(cfg.ttsRate || 1)) $('ttsRate').value = '1';
  $('ttsRate').onchange = () => {
    cfg.ttsRate = parseFloat($('ttsRate').value) || 1; saveCfg();
    try { if (tts.ga) tts.ga.playbackRate = Math.min(2, Math.max(0.5, cfg.ttsRate)); } catch(e) {}   // Google অডিওতে সাথে সাথে প্রযোজ্য
  };
  ttsUI();

  $('btnSave').onclick = () => saveText();
  $('btnProof').onclick = async () => {
    if (cur < 0 || ta.disabled) return;
    if (!sha && !ta.value.trim() && !confirm('এই পেইজে কোনো টেক্সট নেই। তবুও প্রুফড চিহ্নিত করবেন?')) return;
    const ok = await saveText();
    if (!ok) return;
    const stem = images[cur].stem;
    if (!proofed.has(stem)) { if (!(await setProofed(stem, true))) return; }
    if (cur + 1 < images.length) go(cur + 1); else toast('শেষ পেইজ — সেভ ও প্রুফড হয়েছে');
  };
  $('btnToggleProof').onclick = async () => {
    if (cur < 0) return;
    const stem = images[cur].stem;
    await setProofed(stem, !proofed.has(stem));
  };
  $('btnDiscard').onclick = () => {
    if (cur < 0 || ta.disabled) return;
    if (!dirty()) { toast('বাতিল করার মতো অসংরক্ষিত পরিবর্তন নেই'); return; }
    if (!confirm('এই পেইজের অসংরক্ষিত পরিবর্তন/খসড়া বাতিল করে রিপোর টেক্সট ফিরিয়ে আনবেন?')) return;
    ta.value = orig; stashDraft(); updateStatus(); toast('খসড়া বাতিল হয়েছে');
  };

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && ddOpen) { e.preventDefault(); closeDD(); return; }
    if (e.key === 'Escape' && lb.classList.contains('open')) { e.preventDefault(); closeLightbox(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); saveText(); }
    else if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); go(cur + 1); }
    else if (e.altKey && e.key === 'ArrowLeft')  { e.preventDefault(); go(cur - 1); }
  });

  // ব্রাউজার বন্ধ/ব্যাকগ্রাউন্ডে গেলে/ক্র্যাশের আগমুহূর্তে সবকিছু লোকালে রেখে দেওয়া
  // (স্ক্রিন লক করলেও শোনা চলতে পারে; পেইজ বন্ধ হলে শোনা থামবে)
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', () => { flush(); stopPlay(); });
  window.addEventListener('beforeunload', () => { flush(); stopPlay(); });


  // ---------- API (Gemini): এপি আই - ১ = ছবি → টেক্সট, এপি আই - ২ = টেক্সট প্রুফিং ----------
  // ফল সরাসরি টেক্সট বক্সে বসে (পেস্টের মতোই: অটো হেডিং চালু থাকলে 1 বসে, আনডু চলে)।
  // কিছু রিপোতে পুশ হয় না — দেখে নিয়ে আপনি সেভ করলে তবেই পুশ হবে।
  const MIME_BY_EXT = {jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp'};
  const sleep = (ms, signal) => new Promise((res, rej) => {
    const t = setTimeout(res, ms);
    if (signal) signal.addEventListener('abort', () => { clearTimeout(t); rej(new DOMException('Aborted', 'AbortError')); }, {once: true});
  });

  function bytesToB64(buf) {
    const u8 = new Uint8Array(buf); let s = '';
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  }
  async function imageB64(im) {
    let buf;
    try {
      const url = await getImage(im.name);
      buf = await (await fetch(url)).arrayBuffer();
    } catch (e) {                                   // ক্যাশ-URL বাতিল হয়ে গেলে সরাসরি রিপো থেকে
      const r = await api('/contents/' + epath(cfg.pagesDir + '/' + im.name) + refQ(),
                          {headers: {'Accept': 'application/vnd.github.raw+json'}});
      if (!r.ok) throw new Error('ছবি আনা যায়নি: ' + await errMsg(r));
      buf = await r.arrayBuffer();
    }
    const ext = (im.name.split('.').pop() || '').toLowerCase();
    return {mime: MIME_BY_EXT[ext] || 'image/jpeg', data: bytesToB64(buf)};
  }

  function geminiHint(status, msg) {
    const low = (msg || '').toLowerCase();
    if (status === 400 && (low.includes('api key') || low.includes('api_key'))) return ' (API Key ভুল)';
    if (status === 401 || status === 403) return ' (Key-তে অনুমতি নেই / ব্লক / মেয়াদ শেষ)';
    if (status === 404) return ' (মডেলের নাম ভুল হতে পারে)';
    if (status === 429) return ' (কোটা/রেট-লিমিট — একটু পরে আবার চেষ্টা করুন)';
    return '';
  }

  // Gemini streaming (SSE) কল — ছোট ছোট খণ্ডে আসে, তাই বড় পেইজেও সংযোগ ঝুলে যায় না
  async function callGemini(o) {
    const model = o.model.replace(/^models\//, '');
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model)
              + ':streamGenerateContent?alt=sse&key=' + encodeURIComponent(o.key);
    const body = JSON.stringify({contents: [{role: 'user', parts: o.parts}], generationConfig: {temperature: o.temp}});
    let lastErr = null;
    for (let att = 1; att <= 3; att++) {
      let r;
      try {
        r = await fetch(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body, signal: o.signal});
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        lastErr = new Error('নেটওয়ার্ক সমস্যা: ' + e.message);
        if (att < 3) { await sleep(3000 * att, o.signal); continue; }
        throw lastErr;
      }
      if (!r.ok) {
        const t = await r.text(); let m = '';
        try { m = JSON.parse(t).error.message || ''; } catch (e) { m = t.slice(0, 200); }
        lastErr = new Error(r.status + ': ' + m.slice(0, 300) + geminiHint(r.status, m));
        if ([500, 502, 503, 504].includes(r.status) && att < 3) { await sleep(4000 * att, o.signal); continue; }
        throw lastErr;
      }
      const chunks = []; let finish = null, chars = 0;
      const handle = line => {
        if (!line.startsWith('data:')) return;
        const d = line.slice(5).trim();
        if (!d || d === '[DONE]') return;
        let j; try { j = JSON.parse(d); } catch (e) { return; }
        if (j.error) throw new Error((j.error.message || 'API ত্রুটি').slice(0, 300));
        if (j.promptFeedback && j.promptFeedback.blockReason) throw new Error('Gemini ব্লক করেছে: ' + j.promptFeedback.blockReason);
        (j.candidates || []).forEach(c => {
          ((c.content && c.content.parts) || []).forEach(p => { if (typeof p.text === 'string' && !p.thought) { chunks.push(p.text); chars += p.text.length; } });
          if (c.finishReason) finish = c.finishReason;
        });
        if (o.onProgress) o.onProgress(chars);
      };
      const reader = r.body.getReader(), dec = new TextDecoder('utf-8');
      let buf = '';
      for (;;) {
        const {done, value} = await reader.read();
        if (done) break;
        buf += dec.decode(value, {stream: true});
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(l => handle(l.replace(/\r$/, '')));
      }
      buf += dec.decode();
      if (buf) handle(buf.replace(/\r$/, ''));
      let text = chunks.join('').trim();
      const fence = text.match(/^```[A-Za-z]*\r?\n([\s\S]*?)\r?\n```$/);      // ভুলে পুরো আউটপুট কোড-ফেন্সে মুড়ে দিলে খুলে নেওয়া
      if (fence) text = fence[1].trim();
      if (!text) {
        lastErr = new Error('খালি রেসপন্স (finishReason=' + finish + ')');
        if (att < 3) { await sleep(3000 * att, o.signal); continue; }
        throw lastErr;
      }
      return {text, finish};
    }
    throw lastErr || new Error('অজানা ত্রুটি');
  }

  // ভিন্ন লিপির অক্ষর / markdown ধরার সতর্কতা (শুধু জানায়, বদলায় না)
  function checkText(text) {
    const p = [];
    if (/[\u0900-\u0963\u0966-\u097F]/.test(text)) p.push('দেবনাগরী অক্ষর');   // দাঁড়ি ।(U+0964/0965) বাংলাতেও ব্যবহৃত, তাই বাদ
    for (const tok of text.split(/\s+/)) {
      if (/[\u0980-\u09FF]/.test(tok) && AR_RE.test(tok)) { p.push('বাংলা-আরবি মিশ্র শব্দ: ' + tok); break; }
    }
    if (/\*\*|^\s{0,3}#{1,6}\s|^\s*[-*]\s/m.test(text)) p.push('markdown চিহ্ন');
    return p;
  }

  function setApiUI() {
    const b = $('btnApi');
    b.classList.toggle('run', !!apiRun);
    b.title = apiRun ? API_NAME[apiRun.n] + ' চলছে — থামাতে চাপুন' : 'API — ছবি থেকে টেক্সট (এপি আই - ১) / টেক্সট প্রুফিং (এপি আই - ২)';
    updateStatus();
  }

  function applyApiResult(n, stem, text, before, finish) {
    const nm = API_NAME[n];
    const probs = checkText(text);
    const warn = [];
    if (finish === 'MAX_TOKENS') warn.push('আউটপুট অসম্পূর্ণ হতে পারে (MAX_TOKENS)');
    if (probs.length) warn.push(probs.join(' | '));
    const i = images.findIndex(im => im.stem === stem);

    if (cur >= 0 && images[cur].stem === stem && !ta.disabled) {
      if (ta.value !== before && !confirm(nm + ' চলার সময় এই পেইজের টেক্সট বদলেছে। তবুও ফল দিয়ে সব টেক্সট বদলাবেন?')) {
        try { const p = navigator.clipboard.writeText(text); if (p && p.catch) p.catch(() => {}); } catch (e) {}
        toast('ফল বসানো হয়নি (ক্লিপবোর্ডে কপির চেষ্টা করা হয়েছে)', true, 5000);
        return;
      }
      const hn = insertAtStart(text, true, true);        // পেস্টের মতো: আনডু চলে, অটো হেডিং চালু থাকলে 1 বসে
      try { if (window.matchMedia && matchMedia('(pointer:coarse)').matches) ta.blur(); } catch (e) {}   // ফোনে কিবোর্ড খুলে থাকবে না
      const msg = nm + ' সম্পন্ন • ' + text.length + ' অক্ষর' + (hn > 0 ? ' • ' + hn + 'টি হেডিং চিহ্নিত' : '') + ' • দেখে নিয়ে সেভ করুন';
      if (warn.length) toast('⚠ ' + warn.join(' • ') + ' — ' + msg, true, 9000); else toast(msg, false, 4000);
    } else {
      // চলার সময় অন্য পেইজে চলে গেলে: ফল ওই পেইজের খসড়ায় রাখা হয়
      if (cfg.autoHead) text = markHeadings(text).text;
      drafts[dk(stem)] = {t: text, ts: Date.now()}; persistDrafts();
      if (i >= 0) updateOption(i);
      updateStatus();
      toast(nm + ' সম্পন্ন — ফল পেইজ ' + stem + '-এর খসড়ায় রাখা হয়েছে (ওই পেইজে গেলে দেখা যাবে, সেভ করলে পুশ হবে)' + (warn.length ? ' • ⚠ ' + warn.join(' • ') : ''), warn.length > 0, 7000);
    }
  }

  async function runApi(n, opts) {
    const auto = !!(opts && opts.auto);
    if (apiRun) { toast(API_NAME[apiRun.n] + ' চলছে — শেষ হওয়া পর্যন্ত অপেক্ষা করুন', true); return; }
    if (cur < 0 || ta.disabled) { toast('আগে পেইজ লোড হতে দিন', true); return; }
    const c = cfg['api' + n], nm = API_NAME[n];
    const key = (c.key || (n === 2 ? cfg.api1.key : '') || '').trim();
    if (!key) { toast(nm + ': API Key দেওয়া নেই', true); openApiCfg(n); return; }
    if (!c.model) { toast(nm + ': Model দেওয়া নেই', true); openApiCfg(n); return; }
    if (!c.prompt) { toast(nm + ': Prompt খালি', true); openApiCfg(n); return; }

    const im = images[cur], stem = im.stem, before = ta.value;
    if (n === 1 && before.trim() && !confirm('এই পেইজে আগে থেকেই টেক্সট আছে। ' + nm + ' চালালে ছবি থেকে নতুন টেক্সট এসে আগেরটা বদলে দেবে (সেভ না করা পর্যন্ত রিপোতে বদলায় না; আনডু চলে)। চালাবেন?')) return;
    if (n === 2 && !before.trim()) { toast('প্রুফ করার মতো টেক্সট নেই — আগে ' + API_NAME[1] + ' চালান বা টেক্সট বসান', true); return; }

    const ctrl = new AbortController();
    apiRun = {n, stem, ctrl, chars: 0};
    if (n === 1) autoTried.add(stem);   // হাতে চালালেও এই পেইজে আর অটো চলবে না (থামালে আবার নিজে থেকে শুরু হবে না)
    setApiUI();
    toast((auto ? 'অটো: ' : '') + nm + ' চলছে — পেইজ ' + stem + '…', false, 2500);
    let lastUI = 0;
    try {
      const parts = [];
      if (n === 1) {
        const img64 = await imageB64(im);
        parts.push({text: c.prompt}, {inline_data: {mime_type: img64.mime, data: img64.data}});
      } else {
        let p = c.prompt;
        if (/\{\{TEXT\}\}/.test(p)) p = p.replace(/\{\{TEXT\}\}/g, () => before);
        else p += '\n\n===== OCR টেক্সট শুরু =====\n' + before + '\n===== OCR টেক্সট শেষ =====\n';
        parts.push({text: p});
        if (c.sendImg) { const img64 = await imageB64(im); parts.push({inline_data: {mime_type: img64.mime, data: img64.data}}); }
      }
      const res = await callGemini({
        key, model: c.model, parts, temp: Number.isFinite(+c.temp) ? +c.temp : 0, signal: ctrl.signal,
        onProgress: ch => { if (apiRun) { apiRun.chars = ch; const t = Date.now(); if (t - lastUI > 400) { lastUI = t; updateStatus(); } } }
      });
      apiRun = null; setApiUI();
      applyApiResult(n, stem, res.text, before, res.finish);
    } catch (e) {
      const em = (e && e.message) || String(e);
      if (e && e.name === 'AbortError') toast(nm + ' থামানো হয়েছে');
      else if (auto && /^(400|401|403|404|429):/.test(em)) {
        autoPause = true;               // Key/মডেল/কোটার সমস্যায় প্রতি পেইজে একই ত্রুটি না দেখিয়ে অটো থামানো
        toast('অটো ' + nm + ' ব্যর্থ: ' + em + ' — অটো সাময়িক বন্ধ (API ডায়ালগে সংরক্ষণ করলে আবার চালু)', true, 9000);
      }
      else toast((auto ? 'অটো ' : '') + nm + ' ব্যর্থ: ' + em + (auto ? ' — হাতে চালাতে API আইকন চাপুন' : ''), true, 8000);
    } finally { apiRun = null; setApiUI(); maybeAutoOcr(); }
  }

  // টেক্সট ফাঁকা পেইজ খুললে (এবং এপি আই - ১ কনফিগার করা থাকলে) নিজে থেকেই এপি আই - ১ চালায়
  function maybeAutoOcr() {
    clearTimeout(autoT);
    autoT = setTimeout(() => {
      const c = cfg.api1;
      if (!c.auto || autoPause || apiRun) return;
      if (!c.key || !c.model || !c.prompt) return;                       // এপি আই - ১ কনফিগার করা নেই
      if (cur < 0 || ta.disabled || loadErr || initing) return;           // পেইজ/টেক্সট ঠিকমতো লোড হয়নি
      if (document.querySelector('dialog[open]') || lb.classList.contains('open')) return;
      if (ta.value.trim()) return;                                        // টেক্সট (বা খসড়া) আছে
      const stem = images[cur].stem;
      if (proofed.has(stem) || autoTried.has(stem)) return;               // প্রুফড বা এই সেশনে আগেই চলেছে
      runApi(1, {auto: true});
    }, 900);                                                              // দ্রুত পেইজ উল্টানোর সময় অযথা কল ঠেকাতে সামান্য অপেক্ষা
  }

  // ---------- অটো OCR টগল (সবুজ = চালু, লাল = বন্ধ) ----------
  function applyAutoApi() {
    const b = $('btnAutoApi'), on = !!cfg.api1.auto;
    b.classList.toggle('on', on); b.classList.toggle('off', !on);
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.title = on
      ? 'অটো OCR চালু (সবুজ) — ' + API_NAME[1] + '-এর Key দেওয়া থাকলে টেক্সট ফাঁকা পেইজ খুললে নিজে থেকে চলবে। বন্ধ করতে চাপুন'
      : 'অটো OCR বন্ধ (লাল) — API কনফিগার থাকলেও নিজে থেকে চলবে না (হাতে API আইকন থেকে চালানো যাবে)। চালু করতে চাপুন';
  }
  $('btnAutoApi').onclick = () => {
    const c = cfg.api1;
    c.auto = !c.auto; autoPause = false; saveCfg(); applyAutoApi();
    if (c.auto) {
      toast(!c.key ? 'অটো OCR চালু — তবে ' + API_NAME[1] + '-এর Key এখনো দেওয়া নেই' : 'অটো OCR চালু (সবুজ)');
      maybeAutoOcr();
    } else { clearTimeout(autoT); toast('অটো OCR বন্ধ (লাল) — নিজে থেকে আর চলবে না'); }
  };

  // ---------- API ডায়ালগ ----------
  let apiN = 1;
  const keyState = n => (cfg['api' + n].key || (n === 2 && cfg.api1.key)) ? 'Key সেট আছে' : 'Key নেই';
  function openApiPick() {
    [1, 2].forEach(n => { $('apiSub' + n).textContent = API_DEF[n].sub + ' • ' + (cfg['api' + n].model || '—') + ' • ' + keyState(n)
                                                  + (n === 1 && cfg.api1.auto && cfg.api1.key ? ' • অটো চালু' : ''); });
    const d = $('dlgApi'); if (!d.open) d.showModal();
  }
  function openApiCfg(n) {
    apiN = n;
    const c = cfg['api' + n];
    $('aTitle').textContent = API_NAME[n];
    $('aSub').textContent = API_DEF[n].sub + ' • বর্তমান পেইজ: ' + (cur >= 0 ? images[cur].stem : '—');
    $('aKey').value = c.key; $('aModel').value = c.model; $('aPrompt').value = c.prompt; $('aTemp').value = c.temp;
    $('aKey').placeholder = n === 2 ? 'খালি রাখলে ' + API_NAME[1] + '-এর Key ব্যবহার হবে' : 'AIza...';
    $('aKeyHint').textContent = '';
    $('aPromptHint').textContent = n === 1
      ? 'বর্তমান পেইজের ছবি এই প্রম্পটের সাথে পাঠানো হবে; ফল টেক্সট বক্সে বসবে।'
      : 'টেক্সট বক্সের লেখা প্রুফ হবে। প্রম্পটে {{TEXT}} লিখলে টেক্সট ঠিক ঐ জায়গায় বসবে; না লিখলে প্রম্পটের নিচে যুক্ত হবে।';
    $('aImgRow').style.display = n === 2 ? '' : 'none';
    $('aImg').checked = !!c.sendImg;
    $('aAutoRow').style.display = n === 1 ? '' : 'none';
    $('aAutoHint').style.display = n === 1 ? '' : 'none';
    $('aAuto').checked = !!c.auto;
    if ($('dlgApi').open) $('dlgApi').close();
    const d = $('dlgCfg'); if (!d.open) d.showModal();
  }
  function readApiForm() {
    const c = cfg['api' + apiN];
    c.key = $('aKey').value.trim();
    c.model = $('aModel').value.trim().replace(/^models\//, '') || 'gemini-3.5-flash-lite';
    c.prompt = $('aPrompt').value.trim();
    const t = parseFloat($('aTemp').value);
    c.temp = Number.isFinite(t) ? Math.min(2, Math.max(0, t)) : 0;
    if (apiN === 2) c.sendImg = $('aImg').checked;
    if (apiN === 1) c.auto = $('aAuto').checked;
    autoPause = false;                  // নতুন করে সংরক্ষণ করলে অটো আবার চালু
    saveCfg(); applyAutoApi();
  }
  $('btnApi').onclick = () => {
    if (apiRun) { if (confirm(API_NAME[apiRun.n] + ' চলছে। থামাবেন?')) apiRun.ctrl.abort(); return; }
    openApiPick();
  };
  $('apiPick1').onclick = () => openApiCfg(1);
  $('apiPick2').onclick = () => openApiCfg(2);
  $('apiPickClose').onclick = () => $('dlgApi').close();
  $('aCancel').onclick = () => $('dlgCfg').close();
  $('aDefault').onclick = () => { $('aPrompt').value = API_DEF[apiN].prompt; readApiForm(); toast('ডিফল্ট প্রম্পট বসানো ও সংরক্ষিত হয়েছে'); };
  $('aSave').onclick = () => { readApiForm(); $('dlgCfg').close(); toast(API_NAME[apiN] + ' সংরক্ষিত'); };
  $('aRun').onclick = () => {
    readApiForm();
    const c = cfg['api' + apiN];
    if (!(c.key || (apiN === 2 && cfg.api1.key))) { $('aKeyHint').textContent = 'API Key দিন'; $('aKey').focus(); return; }
    if (!c.prompt) { $('aPromptHint').textContent = 'Prompt খালি রাখা যাবে না'; $('aPrompt').focus(); return; }
    $('dlgCfg').close();
    runApi(apiN);
  };

  // API ফর্মের যেকোনো ঘর বদলালেই সাথে সাথে স্বয়ংক্রিয় সংরক্ষণ (Key, Model, Prompt, Temperature, টিক-বক্স)
  ['aKey', 'aModel', 'aPrompt', 'aTemp', 'aImg', 'aAuto'].forEach(id => {
    const el = $(id), h = () => { if ($('dlgCfg').open) readApiForm(); };
    el.addEventListener('input', h); el.addEventListener('change', h);
  });

  // সব <select> কে নিজস্ব ফন্টের ড্রপডাউনে রূপান্তর
  ['sel', 'ttsRate', 'cEngine', 'cVoiceBn', 'cVoiceAr', 'cVoiceEn'].forEach(id => enhanceSelect($(id)));

  applyZoom(); applyFont(); applySwap(); applyAuto(); applyAutoApi(); updateStatus();
  if (!cfg.token) openSettings();   // প্রথমবার টোকেন চাইবে; বাতিল করলে শুধু-পড়া মোডে চলবে
  else init();
})();
})();
