// আইকনে ক্লিক করলে অ্যাপ নতুন ট্যাবে খুলবে (Chrome / Edge / Brave / Opera / Vivaldi / Kiwi / Firefox)
const ext = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
ext.action.onClicked.addListener(() => {
  ext.tabs.create({ url: ext.runtime.getURL('index.html') });
});
